package ez.com.inside.activities.usage;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Charly on 09/12/2017.
 */

public interface OnClickListenerTransition
{
    void onClick(TextView appNameView, ImageView appIconView, int position);
}
