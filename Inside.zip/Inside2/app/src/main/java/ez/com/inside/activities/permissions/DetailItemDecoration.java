package ez.com.inside.activities.permissions;

import android.content.res.Resources;
import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.View;

/**
 * Created by Charly on 05/12/2017.
 */

public class DetailItemDecoration extends RecyclerView.ItemDecoration
{
    private int spaceVertical;

    public DetailItemDecoration()
    {
        Resources r = Resources.getSystem();
        spaceVertical = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 12, r.getDisplayMetrics());
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state)
    {
        outRect.bottom = spaceVertical;

        if(parent.getChildAdapterPosition(view) == 0)
            outRect.top = spaceVertical / 3;
    }
}
