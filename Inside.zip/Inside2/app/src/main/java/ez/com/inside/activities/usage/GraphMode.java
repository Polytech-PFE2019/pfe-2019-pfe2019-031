package ez.com.inside.activities.usage;

/**
 * Created by Charly on 04/12/2017.
 */

public enum GraphMode
{
    WEEKLY,
    MONTHLY,
    YEARLY;
}
