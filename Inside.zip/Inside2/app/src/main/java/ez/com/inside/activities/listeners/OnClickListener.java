package ez.com.inside.activities.listeners;

import android.view.View;

/**
 * Created by Charly on 01/12/2017.
 */

public interface OnClickListener
{
    void onClick(View v, int position);
}
